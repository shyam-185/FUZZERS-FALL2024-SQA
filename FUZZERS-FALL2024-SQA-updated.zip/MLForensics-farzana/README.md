# Forensic Anti-patterns in Machine Learning Engineering 

## Farzana Ahmed Bhuiyan and Akond Rahman 

### Details 

> Demo video for the work in progress: https://drive.google.com/file/d/14lcIbDCIfHu8chqEOS7IX-yEckDFjT8z/view?usp=sharing
